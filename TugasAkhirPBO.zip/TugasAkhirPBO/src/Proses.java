public interface Proses {

    public void totAwal();
    public void totall();
}
