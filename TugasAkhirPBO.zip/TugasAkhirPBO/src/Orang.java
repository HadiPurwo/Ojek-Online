abstract class Orang {
    String nama;
    int no_hp;
    int pilihan;


    public void setNama() {
        System.out.println("Silahkan masukkan nama anda : ");
    }

    public void setNoHp() {
    }
}
