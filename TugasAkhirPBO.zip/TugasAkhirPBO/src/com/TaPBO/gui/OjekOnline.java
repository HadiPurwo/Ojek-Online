package com.TaPBO.gui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class OjekOnline extends JFrame {
    private JPanel OjekOnline;
    private JList<String> ListPenumpang;
    private JTextField textFieldNama;
    private JTextField textFieldNomor;
    private JTextField textFieldAwal;
    private JTextField textFieldTujuan;
    private JTextField textFieldJarak;
    private JButton buttonInsertFirst;
    private JButton buttonInsertLast;
    private JButton buttonClear;

    private DefaultListModel<String> defaultListModel = new DefaultListModel<>();
    private List<OjekOnlineModel> arrayListOjekOnline = new ArrayList<>();
    private LinkedList<OjekOnlineModel> listOjekOnline = new LinkedList<>();

    class OjekOnlineModel {
        private String nama;
        private String nomor;
        private String awal;
        private String tujuan;
        private String jarak;

        public String getNama() {
            return nama;
        }

        public void setNama(String nama) {
            this.nama = nama;
        }

        public String getNomor() {
            return nomor;
        }

        public void setNomor(String nomor) {
            this.nomor = nomor;
        }

        public String getAwal() {
            return awal;
        }

        public void setAwal(String awal) {
            this.awal = awal;
        }

        public String getTujuan() {
            return tujuan;
        }

        public void setTujuan(String tujuan) {
            this.tujuan = tujuan;
        }

        public String getJarak() {
            return jarak;
        }

        public void setJarak(String jarak) {
            this.jarak = jarak;
        }
    }

    public OjekOnline() {
        this.setContentPane(OjekOnline);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        buttonClear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearForm();
            }
        });
        buttonInsertFirst.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nama = textFieldNama.getText();
                String nomor = textFieldNomor.getText();
                String awal = textFieldAwal.getText();
                String tujuan = textFieldTujuan.getText();
                String jarak = textFieldJarak.getText();

                OjekOnlineModel ojekOnline = new OjekOnlineModel();
                ojekOnline.setNama(nama);
                ojekOnline.setNomor(nomor);
                ojekOnline.setAwal(awal);
                ojekOnline.setTujuan(tujuan);
                ojekOnline.setJarak(jarak);

                insertFirst(ojekOnline);
                clearForm();
                refreshDataModel(listOjekOnline);
            }
        });
    }

    private void insertFirst(OjekOnlineModel ojekOnline) {
        listOjekOnline.insertFirst(ojekOnline);
    }

    private void refreshDataModel(LinkedList<OjekOnlineModel> listOjekOnline) {
        arrayListOjekOnline.clear();

        for (OjekOnlineModel ojekOnline : listOjekOnline) {
            if (ojekOnline == null)
                break;

            arrayListOjekOnline.add(ojekOnline);
        }

        defaultListModel.clear();
        for (OjekOnlineModel ojekOnline : arrayListOjekOnline) {
            defaultListModel.addElement(ojekOnline.getNama());
        }
    }

    private void clearForm() {
        textFieldNomor.setText("");
        textFieldNama.setText("");
        textFieldAwal.setText("");
        textFieldTujuan.setText("");
        textFieldJarak.setText("");
    }

    public static void main(String[] args) {
        OjekOnline ojekOnline = new OjekOnline();
        ojekOnline.setVisible(true);
    }
}
